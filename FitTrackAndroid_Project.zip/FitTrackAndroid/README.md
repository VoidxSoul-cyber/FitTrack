# FitTrack Android project

A lightweight Android WebView app containing an offline workout timer.

## Build the APK
1. Install Android Studio (current stable) and the Android SDK Platform 35.
2. Open this `FitTrackAndroid` folder in Android Studio.
3. Allow Gradle sync to finish.
4. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. Find the debug APK at `app/build/outputs/apk/debug/app-debug.apk`.

The app contains the two 8-exercise routines from the supplied charts, three sets, timed intervals, side switching for unilateral movements, 30-second rest between sets, 45-second rest between exercises, pause/resume, reset, skip, and exercise selection.

This project is an initial version. The separate daily reminder set in ChatGPT is not a native Android notification inside the APK.
